<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DaftarIpVps extends Model
{
    protected $guarded = ['id'];
}
