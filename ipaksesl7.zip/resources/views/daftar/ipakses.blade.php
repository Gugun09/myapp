@foreach ($data as $data)
{{ $data->ipkamu }}
@endforeach
